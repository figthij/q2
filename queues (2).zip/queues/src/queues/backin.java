/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package queues;

import java.util.LinkedList;
import java.util.Queue;

/**
 *
 * @author Erik
 */
public class backin {
        public Queue<Character> backin(Queue<Character> q,char c){
        Queue<Character> n;
        n = new LinkedList<>();
        n.add(c);
        for(int x = q.size();x>0;x--){
            n.add(q.remove());
        }
        return n;
    }
    public Queue<String> backins(Queue<String> q,String c){
        Queue<String> n;
        n = new LinkedList<>();
        n.add(c);
        for(int x = q.size();x>0;x--){
            n.add(q.remove());
        }
        return n;
    }
    public Queue<Integer> backini(Queue<Integer> q,int c){
        Queue<Integer> n;
        n = new LinkedList<>();
        n.add(c);
        for(int x = q.size();x>0;x--){
            n.add(q.remove());
        }
        return n;
    }

}
