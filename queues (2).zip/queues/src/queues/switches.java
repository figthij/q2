/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package queues;

/**
 *
 * @author Erik
 */
public class switches {
        public String posswitch(int i){
        String s="";
                switch(i){
                    case 1:
                        s="1";
                        break;
                    case 2:
                        s="2";
                        break;
                    case 3:
                        s="3";
                        break;
                    case 4:
                        s="4";
                        break;
                    case 5:
                        s="5";
                        break;
                    case 6:
                        s="6";
                        break;
                    case 7:
                        s="7";
                        break;
                    case 8:
                        s="8";
                        break;
                    case 9:
                        s="9";
                        break;
                    case 0:
                        s="0";
                        break;
    }
                return s;
    }
    public int charswitch(char i){
        int s=0;
                switch(i){
                    case '1':
                        s=1;
                        break;
                    case '2':
                        s=2;
                        break;
                    case '3':
                        s=3;
                        break;
                    case '4':
                        s=4;
                        break;
                    case '5':
                        s=5;
                        break;
                    case '6':
                        s=6;
                        break;
                    case '7':
                        s=7;
                        break;
                    case '8':
                        s=8;
                        break;
                    case '9':
                        s=9;
                        break;
                    case '0':
                        s=0;
                        break;
    }
                return s;
    }

}
