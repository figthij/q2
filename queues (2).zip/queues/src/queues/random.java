/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package queues;

import java.util.LinkedList;
import java.util.Queue;
import java.util.Random;

/**
 *
 * @author Erik
 */
public class random {
        public Queue<Integer> ran(int top){//makes random numbers between0 and 16
        Random num = new Random();
        int number;
        Queue<Integer> st=new LinkedList();
        number=num.nextInt(10);
        //System.out.println(number);
        st.add(number);
        for(int i=2;i<top;i++){
                number=num.nextInt(10);
                st.add(number);
        }
        number=num.nextInt(10);
        st.add(number);
        return st;
    }
    //change stack to queue
    public Queue<Integer> rans(int top){//makes random numbers between0 and 16
        Random num = new Random();
        int number;
//        Queues<Integer> st=new Queues();
        Queue<Integer> st=new LinkedList<>();
        number=num.nextInt(5);//put at 6 instead of 7 to close parenthesis
        //st.enqueue(number);
        st.add(number);
        for(int i=2;i<top;i++){
                number=num.nextInt(5);
//                st.enqueue(number);
                st.add(number);
        }
        number=num.nextInt(5);
//        st.enqueue(number);
        st.add(number);
        return st;
    }

}
