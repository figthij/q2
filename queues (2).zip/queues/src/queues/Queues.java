/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package queues;
//import static java.lang.Character.isDigit;
import static java.lang.Character.isDigit;
import java.util.LinkedList;
import java.util.Queue;
public class Queues<T> {
//shows which goes first in pemdas char c is the symbol
    static Queue<Character> backup(String s){
        flip f =new flip();
        Queue<Character> nums;
        nums = new LinkedList<>();
     char ch;
        for(int x= s.length()-1;x>=0;x--){
            ch=s.charAt(x);
            nums.add(ch);
  //                  System.out.println("backup "+nums);
        }
        nums=f.flip(nums);
//                            System.out.println("backup "+nums);
        return nums;
    }
    static String convert(String expression){
        precedence p = new precedence();
        flip f =new flip();
        String s="";
        char ca=' ';
        int x1=0;
        int x2=0;
        String result ="";
        Queue<Character> stack = new LinkedList<>();
        Queue<Character> stack2 = new LinkedList<>();
        for(int i =0; i<expression.length();i++){//goes on until there is nothing left to be taken from the expression
            char c= expression.charAt(i);//c is the char at i coming from left to right
            s="";
            if(p.precedence(c)>0){//when c is +-* / or ^
                stack=f.flip(stack);
                while(stack.isEmpty()==false && p.precedence(stack.peek())>=p.precedence(c)){//when the precedence of the next number is more than the current
                    if(ca=='^'&&p.precedence(stack.peek())==3){
                        stack2=backup(result);
                        result="";
                        for(int x=stack2.size();x>0;x--){
                            result+=stack2.remove();
                        }
                        x1=1;
                    }
                    if(x1==0){
                    ca=stack.remove();
                    result +=ca;//if above is the same than it removes c from the stack and puts it in result
                    }
                    else{
                        ca=expression.charAt(i+1);
                    result +=ca;//if above is the same than it removes c from the stack and puts it in result
                    result +=stack.remove();//if above is the same than it removes c from the stack and puts it in result
                        x1=0;
                        x2=1;
                    }
                    stack=f.flip(stack);
                }
                stack.add(c);
            }
            else{//result has number put at end
                if(x2==0){
                result+=c;
                }
                else{
                x2=0;
            }
            }
        }
        for(int i = stack.size(); i>0;i--){
            s +=stack.remove();
        }
        char ch;//c is the char at i coming from left to right
        for(int i =s.length()-1; i>=0;i--){//goes on until there is nothing left to be taken from the expression
            ch=s.charAt(i);
            result+=ch;
        }
        return result;
    }
//starts with stack may need to redo entire evaluate part
    static int evaluateq(Queue<Character> Stack2){//pointer
        precedence p = new precedence();
        backin b = new backin();
        flip f =new flip();
        parser par = new parser();
        Queue<Integer> intStack = new LinkedList<>();//
        Queue<String> sintStack = new LinkedList<>();//
        Queue<Integer> intorsymbol = new LinkedList<>();//1for int 2 for symbol
        Queue<Character> symbol = new LinkedList<>();//
        char ch;
        int i =0,operand1,operand2;
        char op;
        Stack2=f.flip(Stack2);
        char op2;
        String fg = "";
        int sss=Stack2.size();
        while(sss>2){//goes until stack2 is empty
            //puts numbers and symbols into seperate queues to be merged back into stack2 later
            ch = Stack2.poll();
            if(Stack2.isEmpty()==false){
                op=Stack2.poll();
            }
            else{
                op=' ';
            }
            if(Stack2.isEmpty()==false){
                op2=Stack2.poll();
            }            
            else{
                op2=' ';
            }
            Stack2=b.backin(Stack2,op2);
            Stack2=b.backin(Stack2,op);
//            System.out.println(Stack2+" back");
            if(isDigit(ch)){
                intStack.add(ch-'0');
                intorsymbol.add(1);
            }
            else if((isDigit(op))&&(isDigit(op2))){
                intStack.add(op-'0');
                intStack.add(op2-'0');
//                System.out.println(intStack+"hi");
                Stack2.poll();
                Stack2.poll();
                sintStack=par.queuetostringq(intStack);
                sintStack=f.flips(sintStack);
                intStack=par.stringtoint(sintStack);
//                System.out.println(intStack);
                operand2=intStack.poll();
                operand1=intStack.poll();
//                System.out.println(intStack);
                intorsymbol.add(1);
//                System.out.println("ch "+ch);
                switch(ch){
                    case '+':
                        intStack.add(operand1+operand2);
                        break;
                    case '-':
                        intStack.add(operand1-operand2);
                        break;
                    case '*':
                        intStack.add(operand1*operand2);
                        break;
                    case '/':
                        if(operand2!=0){
                            intStack.add(operand1/operand2);
                        }
                        else if(operand2==0){
                            intStack.add(0);
                        }
                        break;
                    case '^':
                        intStack.add((int) Math.pow(operand1, operand2));
                }
//                              System.out.println(intStack);
                sintStack=par.queuetostringq(intStack);
                sintStack=f.flips(sintStack);
                intStack=par.stringtoint(sintStack);
            }
            else{
                fg+=ch;
                symbol.add(ch);
                intorsymbol.add(2);
            }
            sss=Stack2.size();
        }
        while(Stack2.isEmpty()==false){
            ch = Stack2.poll();
            if(isDigit(ch)){
                intStack.add(ch-'0');
                intorsymbol.add(1);
            }
            else{
                fg+=ch;
                symbol.add(ch);
                intorsymbol.add(2);
            }
        }
//            System.out.println(intStack);
//            System.out.println("part2");
        Queue<String> str = new LinkedList<>();//
        Queue<String> ssymbol = new LinkedList<>();//
        sintStack=par.queuetostringq(intStack);
        ssymbol=par.charqueuetostringq(symbol);
        int ssy=ssymbol.size();
        while(ssy!=0){
            int ios=0;
            for(int x=intorsymbol.size();x>0;x--){//merges intstack and symbol back into stack2
                ios=intorsymbol.remove();
                if(ios==1){
                    str.add(sintStack.remove());
            }
            else if(ios==2){
                str.add(ssymbol.remove());
            }
        }
            sss=str.size();
String det="";//ch
String opp="";
String opp2="";
        while(sss>2){//goes until stack2 is empty
            det = str.poll();
//            System.out.println(sintStack);
            if(str.isEmpty()==false){
            opp=str.poll();
            }
            else{
                opp="";
            }
            if(str.isEmpty()==false){
                opp2=str.poll();
            }            
            else{
                opp2="";
            }
            str=b.backins(str,opp2);
            str=b.backins(str,opp);
            if(p.precedences(det)==-1){
                sintStack.add(det);
                intorsymbol.add(1);
            }
            else if((p.precedences(opp)==-1)&&(p.precedences(opp2)==-1)){
                sintStack.add(opp);
                sintStack.add(opp2);
                str.poll();
                str.poll();
                sintStack=f.flips(sintStack);
                intStack=par.stringtoint(sintStack);
                operand2=intStack.poll();
                operand1=intStack.poll();
                intorsymbol.add(1);
                switch(det){
                    case "+":
                        intStack.add(operand1+operand2);
                        sintStack=par.queuetostringq(intStack);
                        break;
                    case "-":
                        intStack.add(operand1-operand2);
                        sintStack=par.queuetostringq(intStack);
                        break;
                    case "*":
                        intStack.add(operand1*operand2);
                        sintStack=par.queuetostringq(intStack);
                        break;
                    case "/":
                        if(operand2!=0){
                            intStack.add(operand1/operand2);
                            sintStack=par.queuetostringq(intStack);
                        }
                        else if(operand2==0){
                            intStack.add(0);
                            sintStack=par.queuetostringq(intStack);
                        }
                        break;
                    case "^":
                        intStack.add((int) Math.pow(operand1, operand2));
                        sintStack=par.queuetostringq(intStack);
                }
            }
            else{
                fg+=det;
                ssymbol.add(det);
                intorsymbol.add(2);
            }
            sss=str.size();
        }
        while(str.isEmpty()==false){
            det = str.poll();
            if(p.precedences(det)==-1){
                sintStack.add(det);
                intorsymbol.add(1);
            }
            else{
            fg+=det;
                ssymbol.add(det);
                intorsymbol.add(2);
            }
        }
ssy=ssymbol.size();
  //      System.out.println(sintStack);
    //    System.out.println(ssymbol);
        }
        intStack=par.stringtoint(sintStack);
//            System.out.println(ssymbol);
//            System.out.println(str);
//        System.out.println(intStack);
                return intStack.peek();
    }
    //should be good now as all are numbers and won't make a difference on order
    //uses stacks may have bto change it but may be able to just change stack into queue
    public static void main(String[] args) {
        parser p = new parser();
        random r =new random();
        String in = "";
        int top=5;
        int tops=4;
        in=p.inttostr(r.ran(top),r.rans(tops),top,tops);
        //in="3+4-2^8^2";//for whatever reason it takes out a five and +
        //still has problems with double ^ 
        String post = convert(in);
        Queue<Character> n=new LinkedList<>();
        n=p.stringtoqueue(post);
        System.out.println("Infix Expression: "+in);
        System.out.println("Postfix Expression: "+post);
        System.out.println("Result is: "+ evaluateq(n));//stackp goes in forward
  }
}
/*    private final Queue<Integer> list;
    public Queues(){
        Queue<Integer> q =new LinkedList<Integer>();
        list=q;
    }
    public boolean isEmpty(){
        return(list.size()==0);
    }
    public void enqueue(int item){
        list.add(item);
    }
    int it =0;
    //try to get this to be int in a differant way
    public int dequeue(){
        int item= list.remove();
        it=it+1;
        return item;
    }
    public int peek(){
        return list.peek();
    }*/
/*
        String s="";
        char ca=' ';
        int x1=0;
        int x2=0;
        String result ="";
        Queue<Character> stack = new LinkedList<>();
        Queue<Character> stack2 = new LinkedList<>();
        for(int i =0; i<expression.length();i++){//goes on until there is nothing left to be taken from the expression
            char c= expression.charAt(i);//c is the char at i coming from left to right
            s="";
            System.out.println("next char is "+c);
                System.out.println("result: "+result);
            if(precedence(c)>0){//when c is +-* / or ^
                stack=flip(stack);
                System.out.println("if");
                System.out.println("result: "+result);
                System.out.println("stack: " + stack);
                System.out.println("stack2: "+stack2);
                System.out.println("c: "+c);
                System.out.println("s: "+s);
                System.out.println();
                while(stack.isEmpty()==false && precedence(stack.peek())>=precedence(c)){//when the precedence of the next number is more than the current
                System.out.println("while");
                System.out.println("result: "+result);
                System.out.println("stack: " + stack);
                System.out.println("stack2: "+stack2);
                System.out.println("c: "+c);
                System.out.println("s: "+s);
                System.out.println();
                    //c is the symbol that occurs later in string
                    //result +=c;//if above is the same than it removes c from the stack and puts it in result
                    //stack=flip(stack);
                
                    if(ca=='^'&&precedence(stack.peek())==3){
                                        System.out.println("if2");
                System.out.println("result: "+result);
                System.out.println("stack: " + stack);
                System.out.println("stack2: "+stack2);
                System.out.println("c: "+c);
                System.out.println("ca: "+ca);
                System.out.println("s: "+s);
                System.out.println();

                        stack2=backup(result);
                    //    System.out.println(stack2);
                        result="";
                        for(int x=stack2.size();x>0;x--){
                System.out.println("for");
                System.out.println("result: "+result);
                System.out.println("stack: " + stack);
                System.out.println("stack2: "+stack2);
                System.out.println("c: "+c);
                System.out.println("s: "+s);
                System.out.println();
                            result+=stack2.remove();
                        }
                        //result+=expression.charAt(i+1);
                        x1=1;
                        System.out.println(result+" "+expression.charAt(i+1)+"           "+expression);
                    }
                    int x3=0;
                    if(x1==0){
                    ca=stack.remove();
                    result +=ca;//if above is the same than it removes c from the stack and puts it in result
                        
                    }
                    else{
                        ca=expression.charAt(i+1);
//                        System.out.println("remove: "+stack.remove());
                    result +=ca;//if above is the same than it removes c from the stack and puts it in result
                    result +=stack.remove();//if above is the same than it removes c from the stack and puts it in result
                        
                        x1=0;
                        x2=1;
                        x3=1;
                    }
                  //  System.out.println("symbol "+ca);
                //    System.out.println("peek "+stack.peek());
//                    if(x3==0){
  //                  result +=ca;//if above is the same than it removes c from the stack and puts it in result
    //                }
//ca=expression.charAt(i+1);
                    stack=flip(stack);
              //      System.out.println("symbol result "+ result + " stack "+ stack);
                }
                
                stack.add(c);
          //      System.out.println("end"+stack);
            }
            else{//result has number put at end
                if(x2==0){
                result+=c;
                }
                else{
                x2=0;
            }
        //        System.out.println("number result "+ result + " stack "+ stack);
                System.out.println(c+"else");
            }
        }
  //      System.out.println("remaining " + stack2);
        for(int i = stack.size(); i>0;i--){
            s +=stack.remove();
//            System.out.println(s);
        }
  //      System.out.println(s.length());
//        System.out.println(s.charAt(1));
        char ch;//c is the char at i coming from left to right
            //expression.charAt(i);
        for(int i =s.length()-1; i>=0;i--){//goes on until there is nothing left to be taken from the expression
    //        System.out.println(result);
            ch=s.charAt(i);
            result+=ch;
        }
        return result;
    }

*/
//uses stacks convers string expression to string result or infix to postfix
/*
    static int evaluate(Stack<Character> postfix){//pointer
        Stack<Integer> intStack = new Stack<>();//
        Stack<Character> Stack2 = new Stack<>();//
        char ch= postfix.peek();
    int i =0,operand1,operand2;
        char op;
        while(postfix.empty()==false){//only stops when ppostfix is empty
            ch = postfix.pop();
            if(isDigit(ch)){//puts ch into stackk2 and leaves it at that
                Stack2.push(ch);
            }
            else{//when ch is a symbol op is set to be the number before it
                op=postfix.peek();
                Stack2.push(ch);
            }
        }
        while(Stack2.empty()==false){//goes until stack2 is empty
            ch = Stack2.pop();
            if(isDigit(ch)){
                intStack.push(ch-'0');
            }
            else{
                operand2=intStack.pop();
                operand1=intStack.pop();
                switch(ch){
                    case '+':
                        intStack.push(operand1+operand2);
                        break;
                    case '-':
                        intStack.push(operand1-operand2);
                        break;
                    case '*':
                        intStack.push(operand1*operand2);
                        break;
                    case '/':
                        if(operand2!=0){
                            intStack.push(operand1/operand2);
                        }
                        else if(operand2==0){
                            intStack.push(0);
                        }
                        break;
                    case '^':
                        intStack.push((int) Math.pow(operand1, operand2));
                }
            }
        }
                return intStack.peek();
    }
/*    static String convert(String expression){
        String s="";
        char ca=' ';
        String result ="";
        Queue<Character> stack = new LinkedList<>();
        Queue<Character> stack2 = new LinkedList<>();
        int skip=0;
        char c=' ';
        System.out.println(expression);

        for(int i =0; i<expression.length();i++){//goes on until there is nothing left to be taken from the expression
            if(skip==0){
            c= expression.charAt(i);//c is the char at i coming from left to right
            System.out.println(result);
            System.out.println("not skip "+c);
            }
            else if(skip==1){
                //stack.remove();
                                System.out.println(result);
                                System.out.println("skip "+c);
                c=' ';
                skip=0;
            }
            s="";
  //          System.out.println(c+"c");
            if(c==' ')
            {
            ///    System.out.println("skip");
            }
            else if(precedence(c)>0){//when c is +-* / or ^
                                stack=flip(stack);
                System.out.println(result);
                System.out.println(stack);
                System.out.println(stack2);
System.out.println();
int d=0;
                while(stack.isEmpty()==false && precedence(stack.peek())>=precedence(c)&&d==0){//when the precedence of the next number is more than the current
                System.out.println("result "+result);
             //       System.out.println("result2 " +result);
                //c is the symbol that occurs later in string
      //              System.out.println("resulc2 " +ca+" "+stack.peek());
                    if(ca=='^'&&precedence(stack.peek())==3){
   //     System.out.println(stack2);
                    System.out.println("result2 " +result);
                        stack2=backup(result);
        //System.out.println(stack);
        System.out.println(stack2);
                        result="";
                        for(int x=stack2.size();x>0;x--){
            //                                    System.out.println("re eeeee" +stack2);
                            result+=stack2.remove();
     //   System.out.println("for" +result);
                        }
                        //implement number before sign here
         //               System.out.println("exp "+expression+" "+i);
                        result+=expression.charAt(i+1);
                        System.out.println("hi"+expression.charAt(i+1)+" "+result);
                        skip=1;
                        
                        
                        
                        
                        //need ^6^+ to be ^^+6+ 
                        
                        
                        
                        
                        
                        
                    }
                    System.out.println(stack);
                    ca=stack.remove();
                                       System.out.println("asdfghjk " +result+" "+ca);

                    result +=ca;//if above is the same than it removes c from the stack and puts it in result
                                       System.out.println("asdfghjk " +result);
                    stack=flip(stack);
                }
                stack.add(c);
                System.out.println("reeeeeeeeeeesult "+result);
                
            }
            else{//result has number put at end
                result+=c;
                System.out.println("c"+c);
            }
                        System.out.println("            "+result);

        }
           //     System.out.println(stack);
        for(int i = stack.size(); i>0;i--){
            s +=stack.remove();
        }
                System.out.println(s.length()+"s"+s);
        char ch;//c is the char at i coming from left to right
    //    for(int i =s.length()-1; i>=0;i--){//goes on until there is nothing left to be taken from the expression
      //      ch=s.charAt(i);
        //    result+=ch;
        //}
        return result;
    }
*/
