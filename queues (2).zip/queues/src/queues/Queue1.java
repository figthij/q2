/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package queues;

import java.util.LinkedList;

/**
 *
 * @author Erik
 */
public class Queue1<T> {
        private LinkedList list;
    public Queue1(){
        list=new LinkedList();
    }
    public boolean isEmpty(){
        return(list.size()==0);
    }
    public void enqueue(Object item){
        list.add(item);
    }
    public Object dequeue(){
        Object item=list.get(1);
        list.remove(0);
        return item;
    }
    public Object peek(){
        return list.get(0);
    }
}
/*        String in = "";
        int top=5;
        int tops=4;
        in=inttostr(ran(top),rans(tops),top,tops);
        String post=convert(in);
        //Stack<Character> stackp = new Stack<>();
        //stackp=stringtostack(post);
        System.out.println("Infix Expression: "+in);
        //String expression="4-5*5/3+7";
//        System.out.println("Infix Expression: "+expression);
        System.out.println("Postfix Expression: "+post);
        System.out.println("Postfix Expression: "+"1953^^/1-");
        //System.out.println("Result is: "+ evaluate(stackp));//stackp goes in forward
  */  /*
        for(int x = stack.size(); x>0;x--){
            s +=stack.remove();
            System.out.println(s);
        //System.out.println(result);
        //System.out.println(stack);
        }
        char ch;//c is the char at i coming from left to right
        for(int x =s.length()-1; x>0;x--){//goes on until there is nothing left to be taken from the expression
            ch=s.charAt(x);
            result+=ch;
            stack2.add(ch);
        }    
*/  
/*
//        PriorityQueue<Integer> q = new PriorityQueue<Integer>();
//        q.offer(1);
  //      q.offer(2);
    //    q.offer(30);
      //  Queues<Integer> queue1=new Queues();
      //  queue1.enqueue(10);
        //System.out.println(queue1.peek());
     //   System.out.println(q.peek());
       // top=q.peek();
        //System.out.println(top);
        //queue1.enqueue(20);
//        ran(top);
  //      rans(tops);
        //Sy//stem.out.printf("%d",q.remove());
        //System.out.printf("%d",q.remove());
        //System.out.printf("%d",q.remove());
       // System.out.printf("%d",q.poll());
        //System.out.println();
     //   top=(int) queue1.dequeue();
        //System.out.println(queue1.peek());
    
*/
/*
   static Stack<Character> stringtostack(String expression){
        Stack<Character> stack = new Stack<>();
        for(int i =0; i<expression.length();i++){
            char c= expression.charAt(i);
            stack.push(c);
        }
        return stack;
    }
    //change to enqueue
    public void push_int(int item){
        intStack.push((Integer) item);
    }
    //change to dequeue
    char pop_int(){
        Integer a=intStack.pop();
        return 0;//may need to delete
    }
 
*/
    /*
        for(int x = stack.size(); x>0;x--){
            s +=stack.remove();
            System.out.println(s);
        //System.out.println(result);
        //System.out.println(stack);
        }
        char ch;//c is the char at i coming from left to right
        for(int x =s.length()-1; x>0;x--){//goes on until there is nothing left to be taken from the expression
            ch=s.charAt(x);
            result+=ch;
            stack2.add(ch);
        }    
*/

/*//    Stack<Integer> intStack = new Stack<>();
            else if(c==')'){
                char x = stack.remove();
//                char x = stack.pop();
                while(x!='('){
                    result += x;
                    x=stack.remove();
//                    x=stack.pop();
                }
            }
            else if(c=='('){
                stack.add(c);
//                stack.push(c);
            }
*/
